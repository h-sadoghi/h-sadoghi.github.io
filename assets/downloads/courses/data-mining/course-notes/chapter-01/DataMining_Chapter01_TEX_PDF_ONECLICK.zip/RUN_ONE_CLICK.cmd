@echo off
setlocal
cd /d "%~dp0"
if not exist "RUN_WITH_ONE_CLICK.html" (
    echo [ERROR] RUN_WITH_ONE_CLICK.html not found in this folder.
    pause
    exit /b 1
)
start "" "%~dp0RUN_WITH_ONE_CLICK.html"
if errorlevel 1 (
    echo Unable to open default web browser. Double-click RUN_WITH_ONE_CLICK.html.
    pause
)
