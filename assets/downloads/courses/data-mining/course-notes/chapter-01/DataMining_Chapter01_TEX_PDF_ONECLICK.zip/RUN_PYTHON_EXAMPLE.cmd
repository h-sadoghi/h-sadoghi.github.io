@echo off
setlocal
cd /d "%~dp0downloads"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "chapter01_example.py"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3 not found. Use RUN_ONE_CLICK.cmd for the browser-based demo.
        pause
        exit /b 1
    )
    python "chapter01_example.py"
)
if errorlevel 1 echo Error in Python example.
echo.
pause
