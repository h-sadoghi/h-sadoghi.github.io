سورس کامل فصل سوم داده‌کاوی.

۱. برای تولید PDF، از ریشه این ZIP فرمان `xelatex DataMining_Chapter03.tex` را دو بار اجرا کنید.
۲. برای Python، وارد downloads شوید و `python -m unittest test_chapter03_examples.py -v` اجرا کنید.
۳. برای بازسازی ۱۸ شکل، فایل `downloads/generate_figures_optional.py` نیازمند numpy/matplotlib/scipy است.
۴. همهٔ داده‌ها و شکل‌ها آموزشی و تألیفی‌اند.
