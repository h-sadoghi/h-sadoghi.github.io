"""Chapter 05 correctness: stdlib unittest."""
import itertools
import math
import random
import unittest
from pathlib import Path
from chapter05_examples import (read_baskets,support_count,apriori,fp_growth,eclat,
    closed_itemsets,maximal_itemsets,association_rules,rule_metrics)
BASE=Path(__file__).parent
class TestChapter05(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.bs=read_baskets(BASE/'baskets_synthetic.csv')
    def test_data(self):self.assertEqual(len(self.bs),8)
    def test_bread(self):self.assertEqual(support_count(self.bs,{'bread'}),6)
    def test_milk(self):self.assertEqual(support_count(self.bs,{'milk'}),6)
    def test_diaper_beer(self):self.assertEqual(support_count(self.bs,{'diaper','beer'}),3)
    def test_bread_milk(self):self.assertEqual(support_count(self.bs,{'bread','milk'}),4)
    def test_triple(self):self.assertEqual(support_count(self.bs,{'bread','milk','diaper'}),2)
    def test_prune(self):self.assertFalse(any(len(x)>2 for x in apriori(self.bs,3)))
    def test_closed_beer(self):self.assertNotIn(frozenset({'beer'}),closed_itemsets(apriori(self.bs,3)))
    def test_maximal(self):
        m=maximal_itemsets(apriori(self.bs,3))
        self.assertIn(frozenset({'eggs'}),m)
        self.assertEqual(len(m),5)
    def test_metrics_lift(self):
        m=rule_metrics(self.bs,['beer'],['diaper'])
        self.assertAlmostEqual(m['lift'],2.0)
        self.assertAlmostEqual(m['confidence'],1.0)
    def test_no_lift(self):
        m=rule_metrics(self.bs,['diaper'],['bread'])
        self.assertAlmostEqual(m['lift'],1.0)
    def test_rules(self):
        rules=association_rules(apriori(self.bs,3),len(self.bs),.7)
        self.assertTrue(any(q['antecedent']==['beer'] and q['consequent']==['diaper'] for q in rules))
    def test_eclat_equal(self):self.assertEqual(apriori(self.bs,3),eclat(self.bs,3))
    def test_fp_equal(self):self.assertEqual(apriori(self.bs,3),fp_growth(self.bs,3))
    def test_fp_equal_multiple(self):
        for s in (1,2,3,4,5,6,7,8):
            self.assertEqual(apriori(self.bs,s),fp_growth(self.bs,s))
    def test_random_cross_comparison(self):
        rng=random.Random(137)
        vocab=list('ABCDE')
        for _ in range(35):
            bs=[frozenset(x for x in vocab if rng.random()<.45) for _ in range(rng.randint(6,25))]
            bs=[b or frozenset({'A'}) for b in bs]
            s=rng.randint(1,len(bs))
            a=apriori(bs,s)
            self.assertEqual(a,eclat(bs,s))
            self.assertEqual(a,fp_growth(bs,s))
    def test_invalid_support(self):
        with self.assertRaises(ValueError):apriori(self.bs,0)
    def test_unique_tid(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.csv';p.write_text('tid,items\nT1,bread\nT1,milk\n',encoding='utf-8')
            with self.assertRaises(ValueError):read_baskets(p)
    def test_anti_monotonic(self):
        freq=apriori(self.bs,2)
        for x,count in freq.items():
            if len(x)>1:
                for subset in itertools.combinations(x,len(x)-1):
                    self.assertGreaterEqual(freq[frozenset(subset)],count)
    def test_exact_rules_coverage(self):
        freq=apriori(self.bs,3)
        for r in association_rules(freq,8,.1):
            self.assertLessEqual(r['confidence'],1.0)
            self.assertGreater(r['lift'],0)
if __name__=='__main__':unittest.main(verbosity=2)
