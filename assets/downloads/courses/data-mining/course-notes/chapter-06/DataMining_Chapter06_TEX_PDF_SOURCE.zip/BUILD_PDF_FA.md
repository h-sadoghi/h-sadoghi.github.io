# راهنمای بازسازی PDF فصل ششم

از داخل این ZIP، بدون تغییر ساختار پوشهٔ `images/`، فایل `DataMining_Chapter06.tex` را با XeLaTeX کامپایل کنید:

```bash
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter06.tex
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter06.tex
```

فونت‌های `Amiri`، `DejaVu Serif` و `DejaVu Sans Mono` و توزیع LaTeX دارای بستهٔ `xepersian` باید نصب باشند. فایل `.tex` از محتوای `chapter06.md` با Pandoc تولید شده؛ برای تغییرهای بنیادی بهتر است ابتدا متن Markdown و ساختار شکل‌ها را اصلاح کنید و سپس TeX تازه تولید کنید.

فایل‌های PDF/Markdown و تصاویر این بسته مستقل از Jupyter Book قابل استفاده‌اند. متن Markdown سایت از MyST figure directive استفاده می‌کند و به پوشهٔ `chapter-06-assets/images/` پس از ورود فصل ارجاع می‌دهد؛ داخل بستهٔ سورس، تصاویر در مسیر `images/` قرار دارند.
