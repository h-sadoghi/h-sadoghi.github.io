# بازسازی PDF فصل هفتم

این ZIP حاوی `DataMining_Chapter07.tex` و ۱۸ شکل همان فصل است. برای ساخت مستقل، توزیع XeLaTeX با بستهٔ `xepersian` و قلم‌های `Amiri`، `DejaVu Serif` و `DejaVu Sans Mono` لازم است.

در مسیر ریشهٔ ZIP:

```
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter07.tex
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter07.tex
```

فایل‌های `chapter07.md` و `for_pdf.md` نیز برای مقایسهٔ منبع Jupyter Book و نسخهٔ چاپی ارائه شده‌اند. منابع علمی فصل Han (فصل ۶) و Tan (فصل‌های ۳ و ۴) هستند و تمام اشکال تازه تولید شده‌اند.
