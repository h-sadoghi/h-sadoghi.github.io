# فصل هشتم داده‌کاوی — اجرای مستقل

این پوشه همهٔ داده‌های نمونه و اسکریپت‌های محاسباتی لازم را دارد؛ اتصال اینترنت و دادهٔ بیرونی فقط برای نصب اولیهٔ وابستگی‌ها ممکن است لازم شود. داده‌ها **کاملاً ساختگی** هستند.

با Python 3.12 یا نسخهٔ سازگار:

```bat
python -m pip install -r requirements.txt
python chapter08_examples.py
python -m unittest -v test_chapter08_examples.py
jupyter notebook chapter08_examples.ipynb
```

در Notebook، فقط دو ویژگی `x1` و `x2` برای خوشه‌بندی استفاده می‌شوند. ستون `synthetic_group` تنها برای بررسی مستقل پس از مدل است. فایل `example_results.json` شامل خروجی اجرای نمونه با بذر ثابت `824` است. قرارداد DBSCAN در کد شمارش *خود نقطه* در `min_samples` است.

ساختار بسته فقط محتواست: `chapter08.md`، `chapter_meta.json`، `images/` و `downloads/`. **برای انتشار** ZIP را با دستور CMD مشخص‌شده به ناشر مستقلِ داخل مخزن بدهید؛ راه‌انداز قدیمی Inbox را اجرا نکنید.
