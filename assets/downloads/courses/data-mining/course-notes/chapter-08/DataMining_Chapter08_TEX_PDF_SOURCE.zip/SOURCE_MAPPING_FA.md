# نقشهٔ منابع — فصل ۸

- Han, Pei & Tong, *Data Mining: Concepts and Techniques*, 4th ed., Chapter 8, Sections 8.1–8.5, printed pp. 379–424: تعریف خوشه، partitioning، hierarchical، DBSCAN، ارزیابی.
- Tan, Steinbach, Karpatne & Kumar, *Introduction to Data Mining*, 2nd ed., Chapter 7, Sections 7.1–7.5, printed pp. 525–596: انواع خوشه، K-means، پیوندهای سلسله‌مراتبی، DBSCAN، روش‌های سنجش اعتبار و null reference.
- محتوای تکمیلی تألیفی: دادهٔ مصنوعی، مثال‌های دستی شش نقطه و پنج نقطه، آزمون تفکیک گروه در دادهٔ یکنواخت، رعایت قرارداد بدون نشت اطلاعات و بازتولید Python.
- فصل ۹: روش‌های طیفی، مدل‌محور و فازی، دادهٔ پُربعد و شبکه‌ای؛ در فصل ۸ عمداً وارد جزئیات آن‌ها نمی‌شویم.
