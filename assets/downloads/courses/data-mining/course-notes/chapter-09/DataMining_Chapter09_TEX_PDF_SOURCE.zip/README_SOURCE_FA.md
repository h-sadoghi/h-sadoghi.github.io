# بازتولید مستقل فصل نهم

در این پوشه، فایل DataMining_Chapter09.tex هم‌سطح پوشهٔ images قرار دارد. پس از Extract، با نصب XeLaTeX و قلم Amiri دستور زیر اجرا شود:

```bat
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter09.tex
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter09.tex
```

برای اجرای محاسبات آموزشی با Python 3.12 و NumPy، در این پوشه:

```bat
py -3.12 -m pip install numpy
py -3.12 chapter09_examples.py
py -3.12 -m unittest -v test_chapter09_examples.py
```

سورس و داده‌ها ساختگی‌اند و به دانلود اطلاعات از بیرون نیاز ندارند. نیاز به نصب اولیهٔ وابستگی‌ها ممکن است وجود داشته باشد.
