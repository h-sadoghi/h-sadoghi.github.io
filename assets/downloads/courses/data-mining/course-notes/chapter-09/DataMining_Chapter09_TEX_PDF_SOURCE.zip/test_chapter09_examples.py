import unittest, tempfile
from pathlib import Path
import numpy as np
import chapter09_examples as ex

class TestChapter09(unittest.TestCase):
    def test_01_posterior(self): self.assertAlmostEqual(ex._posterior_example()[0],.817574476,7)
    def test_02_post_sum(self): self.assertAlmostEqual(sum(ex._posterior_example()),1)
    def test_03_fuzzy(self): self.assertAlmostEqual(ex.fuzzy_membership_1d(2,[0,5])[0],9/13)
    def test_04_fuzzy_sum(self): self.assertAlmostEqual(sum(ex.fuzzy_membership_1d(2,[0,5])),1)
    def test_05_fuzzy_exact(self): self.assertEqual(list(ex.fuzzy_membership_1d(0,[0,5])),[1,0])
    def test_06_fuzzy_invalid(self):
        with self.assertRaises(ValueError): ex.fuzzy_membership_1d(1,[0,3],m=1)
    def test_07_fuzzy_iteration(self):
        centers,u=ex.fuzzy_cmeans_1d([0,.2,4,4.2],[0,4]);self.assertLess(centers[0],.5);self.assertGreater(centers[1],3.5)
    def test_08_gmm_weights(self):
        y=ex.gmm_em_1d([0,.3,1,4,5,5.4]);self.assertAlmostEqual(float(sum(y['weights'])),1)
    def test_09_gmm_responsibilities(self):
        y=ex.gmm_em_1d([0,.3,1,4,5,5.4]);self.assertTrue(np.allclose(y['responsibilities'].sum(axis=1),1))
    def test_10_gmm_monotonic(self):
        y=ex.gmm_em_1d([0,.3,1,4,5,5.4]);self.assertTrue(all(b>=a-1e-8 for a,b in zip(y['loglikelihood'],y['loglikelihood'][1:])))
    def test_11_gmm_invalid(self):
        with self.assertRaises(ValueError): ex.gmm_em_1d([1,2])
    def test_12_bic_parameters(self): self.assertEqual(ex.gmm_bic(0,100,n_components=2,dim=1),5*np.log(100))
    def test_13_graph_laplacian(self):
        w=np.array([[0,1],[1,0]]);self.assertTrue(np.allclose(ex.graph_laplacian(w),[[1,-1],[-1,1]]))
    def test_14_graph_invalid(self):
        with self.assertRaises(ValueError): ex.graph_laplacian([[0,1],[0,0]])
    def test_15_spectral_components(self):
        w=np.diag([0.,0.,0.,0.]);w[0,1]=w[1,0]=1;w[2,3]=w[3,2]=1
        ev,emb=ex.spectral_embedding(w);self.assertLess(abs(ev[0]),1e-8);self.assertLess(abs(ev[1]),1e-8)
    def test_16_spectral_unit_rows(self):
        w=np.ones((4,4))-np.eye(4);_,emb=ex.spectral_embedding(w);self.assertTrue(np.allclose(np.linalg.norm(emb,axis=1),1))
    def test_17_snn(self):self.assertEqual(ex.shared_neighbor_similarity([2,3,4],[2,4,5]),2)
    def test_18_bicluster_zero(self):
        a=np.array([[1,2,3],[2,3,4],[3,4,5]]);self.assertAlmostEqual(ex.bicluster_msr(a),0)
    def test_19_bicluster_not_zero(self):self.assertGreater(ex.bicluster_msr([[1,1],[1,10]]),1)
    def test_20_cf(self):
        a=np.array([[1.,1.],[2.,1.],[5.,4.]]);c=ex.cf_summary(a);self.assertAlmostEqual(ex.cf_sse(c),np.sum((a-a.mean(axis=0))**2))
    def test_21_cf_merge(self):
        a=np.array([[0.,1.],[1.,1.],[5.,4.]])
        merged=ex.merge_cf(ex.cf_summary(a[:1]),ex.cf_summary(a[1:]));self.assertAlmostEqual(ex.cf_sse(merged),ex.cf_sse(ex.cf_summary(a)))
    def test_22_nmf_nonnegative(self):
        v=np.array([[1,2,3],[2,4,6],[3,6,9]],float);w,h,e=ex.nmf_mu(v,rank=1,steps=100);self.assertTrue((w>=0).all() and (h>=0).all())
    def test_23_nmf_decreasing(self):
        v=np.array([[1,2,3],[2,4,6],[3,6,9]],float);_,_,e=ex.nmf_mu(v,rank=1,steps=100);self.assertLessEqual(e[-1],e[0]+1e-8)
    def test_24_nmf_invalid(self):
        with self.assertRaises(ValueError):ex.nmf_mu([[-1,0],[1,2]])
    def test_25_files(self):
        with tempfile.TemporaryDirectory() as t:
            a,b,c,w=ex.make_data(t);self.assertEqual(a.shape,(220,2));self.assertEqual(b.shape,(220,20));self.assertEqual(c.shape,(10,9));self.assertTrue((Path(t)/'network_synthetic.json').is_file())
    def test_26_demo(self):
        with tempfile.TemporaryDirectory() as t:
            o=ex.demo(t);self.assertEqual(o['synthetic_rows'],220);self.assertEqual(o['cf_n'],3)

if __name__=='__main__':unittest.main(verbosity=2)
