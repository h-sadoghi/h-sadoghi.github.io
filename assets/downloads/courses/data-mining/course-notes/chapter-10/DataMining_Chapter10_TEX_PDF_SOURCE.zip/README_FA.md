# راهنمای بازتولید فصل دهم Data Mining

**موضوع:** تشخیص ناهنجاری، امتیازدهی مقاوم و محلی، ارزیابی و پایش.

## بسته چه دارد؟

- `DataMining_Chapter10.pdf`: نسخهٔ آمادهٔ مطالعه با صفحه‌بندی A4.
- `DataMining_Chapter10_TEX_PDF_SOURCE.zip`: سورس مستقل XeLaTeX و بیست شکل و کدها.
- `chapter10_examples.py`: پیاده‌سازی‌های شفاف؛ فقط NumPy نیاز دارد.
- `chapter10_examples.ipynb`: Notebook با خروجی‌های اجراشده.
- `events_synthetic.csv`: ۳۰۰ تراکنش کاملاً ساختگی با ۱۵ ناهنجاری تزریق‌شده.
- `signals_synthetic.json`: نمونه‌های مصنوعیِ نقطه‌ای و تغییرِ جمعی.
- `example_results.json`: نتایج اجرای مرجع با بذر ثابت.
- `test_chapter10_examples.py`: ۲۶ آزمون واحد بر اساس unittest.
- `SOURCE_MAPPING_FA.md`: تناظر مفاهیم با بخش‌های دو کتاب اصلی.

## اجرای CMD ویندوز برای مثال‌ها

در پوشه‌ای که `chapter10_examples.py` قرار دارد، CMD را باز کنید:

```bat
py -3.12 -m pip install -r requirements.txt
py -3.12 chapter10_examples.py
py -3.12 -m unittest -v test_chapter10_examples.py
py -3.12 -m jupyter notebook chapter10_examples.ipynb
```

برای فقط اجرای Python، `numpy` کافی است؛ Matplotlib، Jupyter و nbclient برای نمودار و Notebook هستند. نیازی به شبکه در خود مثال‌ها نیست؛ نصب بسته‌های Python ممکن است در رایانهٔ فاقد وابستگی به اینترنت نیاز داشته باشد.

## بازسازی مستقل PDF

در ZIP سورس، فایل `.tex` در کنار پوشهٔ `images/` قرار دارد. پس از استخراج فایل‌ها در یک پوشه:

```bat
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter10.tex
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter10.tex
```

به XeLaTeX، بستهٔ `xepersian` و فونت‌های `Amiri` و `DejaVu Serif` نیاز است. سورس از تصویر یا قلم روی اینترنت استفاده نمی‌کند.

## دقت علمی و محدودیت‌ها

- `synthetic_truth_for_evaluation_only` در دادهٔ CSV **فقط** برای ارزیابی است، نه ورودی مدل ناهنجاری.
- مرجع زمینه‌ای در مثال، ۲۰۰ رکورد اول است و به‌طور عمدی می‌تواند آلوده باشد؛ این مثال، اعتبارسنجی کامل یک سامانهٔ واقعی نیست.
- `lof_fixed_k` مدل آموزشی با دقیقاً $k$ همسایه است؛ در تساوی فاصله، قرارداد بعضی کتابخانه‌ها متفاوت است.
- مقادیر score نه احتمال تقلب‌اند و نه مجوز تصمیم خودکار دربارهٔ افراد.
- کد هسته فقط NumPy می‌خواهد؛ الگوریتم Isolation Forest و One-class SVM در متن تشریح شده‌اند، اما در هستهٔ آموزشی از صفر پیاده نشده‌اند.
