"""Offline standard-library unittest: run python -m unittest -v test_chapter10_examples.py"""
import unittest
import numpy as np
import chapter10_examples as m

class Scores(unittest.TestCase):
    def test_median_robust(self): self.assertAlmostEqual(m.robust_z([48],[10,11,11,12,12,13,13,14,15,48])[0],15.962924087973933,places=4)
    def test_robust_center(self):self.assertAlmostEqual(m.robust_z([12.5],[10,11,11,12,12,13,13,14,15,48])[0],0)
    def test_reference_not_query(self):self.assertGreater(m.robust_z([40],[10,11,12,13,14])[0],10)
    def test_mad_zero_guard(self):
        with self.assertRaises(ValueError):m.robust_z([3],[3,3,3,3])
    def test_bad_robust(self):
        with self.assertRaises(ValueError):m.robust_z([np.nan],[0,1,2])
    def test_iqr_bounds(self):self.assertEqual(len(m.tukey_bounds([0,1,2,3,4,5])),2)
    def test_k_distance(self):np.testing.assert_allclose(m.k_neighbor_scores([[0],[1],[2]],k=1,exclude_self=True),[1,1,1])
    def test_k_outsample(self):np.testing.assert_allclose(m.k_neighbor_scores([[2]],[[-1],[0],[1]],k=2),[2])
    def test_self_error(self):
        with self.assertRaises(ValueError):m.k_neighbor_scores([[0]],[[1]],k=1,exclude_self=True)
    def test_lof_positive(self):self.assertTrue((m.lof_fixed_k([[0],[.1],[.2],[.3],[.4],[1.8]])>0).all())
    def test_lof_outlier(self):self.assertGreater(m.lof_fixed_k([[0],[.1],[.2],[.3],[.4],[1.8]])[-1],3)
    def test_lof_invalid_k(self):
        with self.assertRaises(ValueError):m.lof_fixed_k([[0],[1]],2)
    def test_mahalanobis(self):self.assertGreater(m.mahalanobis_scores([[10,10]],[[0,0],[0,1],[1,0],[1,1]])[0],5)
    def test_mahalanobis_singular(self):self.assertTrue(np.isfinite(m.mahalanobis_scores([[3,3]],[[0,0],[1,1],[2,2]])).all())
    def test_context(self):np.testing.assert_allclose(m.contextual_score([10,100],['A','B'],[9,10,11,99,100,101],['A']*3+['B']*3),[0,0])
    def test_unknown_context(self):
        with self.assertRaises(ValueError):m.contextual_score([1],['Z'],[1,2],['A','A'])
    def test_window(self):self.assertTrue(np.isnan(m.scan_window_mean([1,2,3],2)[0]));self.assertAlmostEqual(m.scan_window_mean([1,2,3],2)[-1],2.5)
    def test_cusum(self):np.testing.assert_allclose(m.positive_cusum([0,1,2],drift=.5),[0,.5,2])
    def test_precision(self):self.assertEqual(m.precision_recall_at_k([0,1,0,1],[.1,.9,.2,.8],2)['hits'],2)
    def test_recall_none(self):self.assertIsNone(m.precision_recall_at_k([0,0],[.3,.7],1)['recall_at_k'])
    def test_confusion(self):self.assertEqual(m.confusion_at_threshold([0,1,0,1],[.1,.9,.8,.7],.75),{'TP':1,'FP':1,'FN':1,'TN':1})
    def test_synthetic_repro(self):self.assertEqual(m.make_synthetic(),m.make_synthetic())
    def test_synthetic_count(self):self.assertEqual(sum(r['synthetic_truth_for_evaluation_only'] for r in m.make_synthetic()),15)
    def test_scores_all_finite(self):self.assertTrue(np.isfinite(m.lof_fixed_k([[0],[1],[2],[5],[9]])).all())
    def test_iqr_outlier(self):self.assertGreater(48,m.tukey_bounds([10,11,11,12,12,13,13,14,15,48])[1])
    def test_topk_ties(self):self.assertEqual(m.precision_recall_at_k([1,0,1],[.7,.7,.7],1)['hits'],1)

if __name__=='__main__':unittest.main()
