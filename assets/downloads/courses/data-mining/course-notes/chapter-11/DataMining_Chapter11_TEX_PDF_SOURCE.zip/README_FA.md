# فصل یازدهم — راهنمای اجرای مستقل

محتوای علمی: آزمون فرض و جلوگیری از کشفیات کاذب. داده‌ها همگی ساختگی هستند و اینترنت لازم نیست.

## اجرا با Python 3.12 در CMD

```bat
cd /d "PATH_TO_DOWNLOADS"
py -3.12 chapter11_examples.py
py -3.12 -m unittest -v test_chapter11_examples.py
```

محاسبات هسته فقط از کتابخانهٔ استاندارد Python استفاده می‌کنند؛ Notebook نیز با Jupyter/nbclient اجراشده است. برای نمودارهای جدید به `numpy`، `matplotlib` نیاز است. فایل `chapter11_examples.ipynb` خروجی‌های ذخیره‌شدهٔ واقعی دارد.

## بازتولید PDF از ZIP سورس

ZIP سورس را جداگانه استخراج کنید. در پوشهٔ استخراج‌شده:
```bat
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter11.tex
xelatex -interaction=nonstopmode -halt-on-error DataMining_Chapter11.tex
```
نیازمند XeLaTeX و قلم Amiri، DejaVu Serif و بستهٔ xepersian است. PDF فارسی با A4 ساخته شده و تصاویر `images/` در همان ZIP وجود دارند.

## تفاوت آزمون‌ها

مقدار p احتمال درست‌بودن فرض صفر نیست. BH در سطح FDR، Holm در سطح FWER کار می‌کند. آزمایش عددی برای آموزش است و ادعای تجربی خارج از دادهٔ مصنوعی نیست.
