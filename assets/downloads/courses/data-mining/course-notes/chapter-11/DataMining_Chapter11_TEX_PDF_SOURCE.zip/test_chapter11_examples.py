import unittest,math
from chapter11_examples import *

class Chapter11Tests(unittest.TestCase):
    def test_binomial_8of10(self):self.assertAlmostEqual(binomial_upper_tail(8,10),56/1024)
    def test_binomial_9of10(self):self.assertAlmostEqual(binomial_upper_tail(9,10),11/1024)
    def test_binomial_bound(self):self.assertAlmostEqual(binomial_upper_tail(0,10),1)
    def test_binomial_edge(self):self.assertAlmostEqual(binomial_upper_tail(1,1,1),1)
    def test_binomial_bad(self):
        with self.assertRaises(ValueError):binomial_upper_tail(2,1)
    def test_wilson(self):
        l,u=wilson_interval(8,10);self.assertTrue(.48<l<.51 and .93<u<.95)
    def test_wilson_bounds(self):
        self.assertGreaterEqual(wilson_interval(0,5)[0],0)
        self.assertLessEqual(wilson_interval(5,5)[1],1)
    def test_wilson_invalid(self):
        with self.assertRaises(ValueError):wilson_interval(0,0)
    def test_bonf(self):self.assertEqual(bonferroni([0.01,0.20]),[.02,.4])
    def test_bonf_cap(self):self.assertEqual(bonferroni([0.99,0.60]),[1.,1.])
    def test_holm_example(self):self.assertEqual(discoveries(holm([.001,.012,.021,.039,.20,.61])),[0])
    def test_bh_example(self):self.assertEqual(discoveries(benjamini_hochberg([.001,.012,.021,.039,.20,.61])),[0,1,2])
    def test_bh_permutation(self):
        p=[.61,.021,.001,.20,.039,.012]
        q=benjamini_hochberg(p);self.assertEqual(discoveries(q),[1,2,5])
    def test_bh_monotonicity(self):
        p=[0.4,0.02,0.06,0.03];q=benjamini_hochberg(p)
        self.assertEqual(sorted(range(len(p)),key=lambda i:p[i]),sorted(range(len(p)),key=lambda i:q[i]))
    def test_adjust_empty(self):self.assertEqual(holm([]),[])
    def test_adjust_bad(self):
        with self.assertRaises(ValueError):holm([float('nan')])
    def test_mcnemar(self):self.assertEqual(mcnemar_exact([1]*6+[0]*6,[0]*12),(6,0,.03125))
    def test_mcnemar_equal(self):self.assertEqual(mcnemar_exact([1,0],[1,0]),(0,0,1.0))
    def test_exact_perm(self):self.assertAlmostEqual(exact_permutation_difference([8,9,10],[1,2,3]),.1)
    def test_approx_perm(self):
        v,p=permutation_difference([8,9,10],[1,2,3],999,seed=123);self.assertAlmostEqual(v,7)
        self.assertTrue(0<p<.2)
    def test_permutation_reproducible(self):
        self.assertEqual(permutation_difference([1,2,3],[4,5,6],999),permutation_difference([1,2,3],[4,5,6],999))
    def test_bootstrap(self):
        lo,hi=bootstrap_mean_difference([8,9,10],[1,2,3],1000)
        self.assertTrue(0<lo<hi<11)
    def test_fisher_one(self):self.assertAlmostEqual(fisher_association(1,0,0,1),.5)
    def test_fisher_symmetry(self):self.assertAlmostEqual(fisher_association(12,8,6,24),fisher_association(12,6,8,24))
    def test_fisher_bad(self):
        with self.assertRaises(ValueError):fisher_association(-1,0,0,1)
    def test_overlap(self):self.assertEqual(random_split_overlap(),0)
    def test_null_samples(self):
        p=max_signal_null(100,20);self.assertEqual(len(p),100)
        self.assertTrue(all(0<v<1 for v in p))
    def test_holm_fwer_arbitrary(self):self.assertTrue(all(0<=x<=1 for x in holm([.01,.4,.9])))
    def test_bh_zero(self):self.assertEqual(benjamini_hochberg([0,0,0]),[0,0,0])
    def test_bh_one(self):self.assertEqual(benjamini_hochberg([1,1,1]),[1,1,1])

if __name__=='__main__':unittest.main(verbosity=2)
