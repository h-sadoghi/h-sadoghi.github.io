# Chapter 4 — Reproducible frequency-domain experiments

Includes nine standalone demonstrations from the provided chapter source and one self-contained teaching script and notebook. Requires numpy, matplotlib, Pillow. From `chapter04_code/`, run each Python script. The scripts save outputs to a sibling `chapter04_code_outputs/` directory. The synthetic sample image is supplied. No setup/command batch files are included.
