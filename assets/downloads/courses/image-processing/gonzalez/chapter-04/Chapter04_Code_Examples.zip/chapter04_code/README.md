# Chapter 4 executable demonstrations

All scripts use Python 3, NumPy, Matplotlib, and Pillow. Run them from this
directory. Each script writes one verified PNG result to
`../chapter04_code_outputs/`.

```bash
python sampling_aliasing_demo.py
python spectrum_phase_demo.py
python convolution_padding_demo.py
python frequency_filter_pipeline.py
python lowpass_filter_comparison.py
python highpass_sharpening_demo.py
python homomorphic_filter_demo.py
python notch_filter_demo.py
python fft_runtime_demo.py
```

