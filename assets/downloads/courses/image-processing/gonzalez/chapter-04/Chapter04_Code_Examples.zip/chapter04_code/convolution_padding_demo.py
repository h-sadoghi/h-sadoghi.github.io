"""Compare circular convolution with zero-padded linear convolution."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray(192)
kernel = np.ones((31, 31), dtype=float)
kernel /= kernel.sum()

kernel_circular = np.zeros_like(image)
kernel_circular[:31, :31] = kernel
kernel_circular = np.roll(kernel_circular, (-15, -15), axis=(0, 1))
circular = np.real(np.fft.ifft2(np.fft.fft2(image) * np.fft.fft2(kernel_circular)))

shape = (image.shape[0] + 30, image.shape[1] + 30)
padded_image = np.zeros(shape)
padded_kernel = np.zeros(shape)
padded_image[: image.shape[0], : image.shape[1]] = image
padded_kernel[:31, :31] = kernel
linear_full = np.real(np.fft.ifft2(np.fft.fft2(padded_image) * np.fft.fft2(padded_kernel)))
linear = linear_full[15:15 + image.shape[0], 15:15 + image.shape[1]]

fig, axes = plt.subplots(1, 3, figsize=(12, 4))
for axis, array, title in zip(
    axes,
    (image, circular, linear),
    ("Original", "Circular convolution", "Linear convolution with padding"),
):
    axis.imshow(normalize(array), cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "convolution_padding_result.png", dpi=180)

