"""Shared utilities for Chapter 4 frequency-domain demonstrations."""

from pathlib import Path

import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "chapter04_code_outputs"
SAMPLE = Path(__file__).resolve().parent / "sample_image.png"


def load_gray(size: int = 256) -> np.ndarray:
    image = Image.open(SAMPLE).convert("L").resize((size, size))
    return np.asarray(image, dtype=np.float64) / 255.0


def normalize(array: np.ndarray) -> np.ndarray:
    array = np.real(array)
    low, high = np.percentile(array, (1, 99))
    return np.clip((array - low) / max(high - low, 1e-12), 0, 1)


def distance_grid(shape: tuple[int, int]) -> np.ndarray:
    rows, cols = shape
    y = np.arange(rows) - rows // 2
    x = np.arange(cols) - cols // 2
    xx, yy = np.meshgrid(x, y)
    return np.hypot(xx, yy)


def apply_filter(image: np.ndarray, transfer: np.ndarray) -> np.ndarray:
    spectrum = np.fft.fftshift(np.fft.fft2(image))
    return np.real(np.fft.ifft2(np.fft.ifftshift(spectrum * transfer)))

