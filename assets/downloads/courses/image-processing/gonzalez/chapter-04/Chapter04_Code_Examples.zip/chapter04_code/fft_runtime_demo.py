"""Compare direct DFT time with FFT time for short one-dimensional signals."""

import time

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT


OUTPUT.mkdir(exist_ok=True)
sizes = np.array([64, 128, 256, 512, 1024])
direct_times, fft_times = [], []
rng = np.random.default_rng(7)
for size in sizes:
    signal = rng.normal(size=size)
    index = np.arange(size)
    matrix = np.exp(-2j * np.pi * np.outer(index, index) / size)
    direct_trials = []
    for _ in range(9):
        start = time.perf_counter()
        matrix @ signal
        direct_trials.append(time.perf_counter() - start)
    fft_trials = []
    for _ in range(200):
        start = time.perf_counter()
        np.fft.fft(signal)
        fft_trials.append(time.perf_counter() - start)
    direct_times.append(np.median(direct_trials))
    fft_times.append(np.median(fft_trials))

fig, axis = plt.subplots(figsize=(8, 5))
axis.plot(sizes, direct_times, "o-", label="Direct DFT")
axis.plot(sizes, fft_times, "o-", label="FFT")
axis.set_yscale("log")
axis.set_xlabel("Signal length")
axis.set_ylabel("Execution time (s, log scale)")
axis.set_title("Direct DFT versus FFT runtime")
axis.grid(alpha=0.3)
axis.legend()
fig.tight_layout()
fig.savefig(OUTPUT / "fft_runtime_result.png", dpi=180)
