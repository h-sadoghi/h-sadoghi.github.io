"""Show the main stages of frequency-domain filtering."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, apply_filter, distance_grid, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
distance = distance_grid(image.shape)
transfer = np.exp(-(distance ** 2) / (2 * 24 ** 2))
spectrum = np.fft.fftshift(np.fft.fft2(image))
filtered_spectrum = spectrum * transfer
result = apply_filter(image, transfer)

fig, axes = plt.subplots(1, 5, figsize=(16, 3.5))
items = [
    (image, "Input image"),
    (np.log1p(np.abs(spectrum)), "Centered spectrum"),
    (transfer, "Gaussian transfer function"),
    (np.log1p(np.abs(filtered_spectrum)), "Filtered spectrum"),
    (normalize(result), "IDFT result"),
]
for axis, (array, title) in zip(axes, items):
    axis.imshow(array, cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "frequency_filter_pipeline_result.png", dpi=180)

