"""Frequency-domain highpass filtering and high-boost sharpening."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, apply_filter, distance_grid, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
distance = distance_grid(image.shape)
lowpass = np.exp(-(distance ** 2) / (2 * 18 ** 2))
highpass = 1 - lowpass
detail = apply_filter(image, highpass)
highboost = image + 1.8 * detail

fig, axes = plt.subplots(1, 4, figsize=(13, 4))
items = [
    (image, "Original"),
    (highpass, "Gaussian HPF"),
    (normalize(detail), "High-frequency detail"),
    (normalize(highboost), "High-boost result"),
]
for axis, (array, title) in zip(axes, items):
    axis.imshow(array, cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "highpass_sharpening_result.png", dpi=180)

