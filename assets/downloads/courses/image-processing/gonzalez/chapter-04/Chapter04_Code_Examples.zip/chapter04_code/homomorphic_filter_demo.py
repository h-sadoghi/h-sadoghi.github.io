"""Homomorphic filtering for illumination compression and detail enhancement."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, distance_grid, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
rows, cols = image.shape
illumination = np.linspace(0.35, 1.0, cols)[None, :]
degraded = np.clip(image * illumination, 0, 1)
log_image = np.log1p(degraded)
distance = distance_grid(image.shape)
gamma_low, gamma_high, cutoff, sharpness = 0.45, 1.8, 28.0, 1.2
transfer = (gamma_high - gamma_low) * (1 - np.exp(-sharpness * distance ** 2 / cutoff ** 2)) + gamma_low
spectrum = np.fft.fftshift(np.fft.fft2(log_image))
filtered = np.real(np.fft.ifft2(np.fft.ifftshift(spectrum * transfer)))
result = np.expm1(filtered)

fig, axes = plt.subplots(1, 4, figsize=(13, 4))
items = [
    (image, "Reference"),
    (degraded, "Uneven illumination"),
    (transfer, "Homomorphic filter"),
    (normalize(result), "Filtered result"),
]
for axis, (array, title) in zip(axes, items):
    axis.imshow(array, cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "homomorphic_filter_result.png", dpi=180)

