"""Compare ideal, Gaussian, and Butterworth lowpass filters."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, apply_filter, distance_grid, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
distance = distance_grid(image.shape)
cutoff = 24.0
ideal = (distance <= cutoff).astype(float)
gaussian = np.exp(-(distance ** 2) / (2 * cutoff ** 2))
butterworth = 1 / (1 + (distance / cutoff) ** (2 * 3))
filters = [(ideal, "Ideal LPF"), (gaussian, "Gaussian LPF"), (butterworth, "Butterworth LPF, n=3")]

fig, axes = plt.subplots(2, 3, figsize=(11, 7))
for column, (transfer, title) in enumerate(filters):
    axes[0, column].imshow(transfer, cmap="gray")
    axes[0, column].set_title(title)
    axes[1, column].imshow(normalize(apply_filter(image, transfer)), cmap="gray")
    axes[1, column].set_title("Filtered image")
    axes[0, column].axis("off")
    axes[1, column].axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "lowpass_filter_comparison_result.png", dpi=180)

