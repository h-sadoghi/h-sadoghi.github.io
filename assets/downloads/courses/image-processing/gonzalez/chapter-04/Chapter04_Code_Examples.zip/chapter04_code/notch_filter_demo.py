"""Remove synthetic periodic interference with symmetric notch-reject filters."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
rows, cols = image.shape
y, x = np.mgrid[0:rows, 0:cols]
corrupted = np.clip(image + 0.22 * np.sin(2 * np.pi * 22 * x / cols), 0, 1)
spectrum = np.fft.fftshift(np.fft.fft2(corrupted))
transfer = np.ones_like(image)
cy, cx = rows // 2, cols // 2
for offset in (-22, 22):
    distance = np.hypot(x - (cx + offset), y - cy)
    transfer *= 1 - np.exp(-(distance ** 2) / (2 * 3.0 ** 2))
filtered = np.real(np.fft.ifft2(np.fft.ifftshift(spectrum * transfer)))

fig, axes = plt.subplots(2, 2, figsize=(9, 8))
items = [
    (corrupted, "Image with periodic interference"),
    (np.log1p(np.abs(spectrum)), "Spectrum with symmetric spikes"),
    (transfer, "Notch-reject transfer function"),
    (normalize(filtered), "Filtered image"),
]
for axis, (array, title) in zip(axes.ravel(), items):
    axis.imshow(array, cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "notch_filter_result.png", dpi=180)

