"""Sampling above and below the Nyquist rate."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT


OUTPUT.mkdir(exist_ok=True)
frequency = 7.0
t = np.linspace(0, 1, 2000, endpoint=False)
signal = np.sin(2 * np.pi * frequency * t)

fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
for axis, rate, label in zip(axes, (30, 10), ("Above Nyquist", "Below Nyquist: aliasing")):
    ts = np.arange(0, 1, 1 / rate)
    samples = np.sin(2 * np.pi * frequency * ts)
    axis.plot(t, signal, color="0.75", label="Continuous signal")
    axis.plot(ts, samples, "o-", label=f"Samples at {rate} Hz")
    axis.set_title(label)
    axis.set_ylabel("Amplitude")
    axis.grid(alpha=0.25)
    axis.legend(loc="upper right")
axes[-1].set_xlabel("Time (s)")
fig.tight_layout()
fig.savefig(OUTPUT / "sampling_aliasing_result.png", dpi=180)

