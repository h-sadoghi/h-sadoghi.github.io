"""Demonstrate the different roles of Fourier magnitude and phase."""

import matplotlib.pyplot as plt
import numpy as np

from demo_utils import OUTPUT, load_gray, normalize


OUTPUT.mkdir(exist_ok=True)
image = load_gray()
spectrum = np.fft.fft2(image)
magnitude = np.abs(spectrum)
phase = np.angle(spectrum)
phase_only = np.real(np.fft.ifft2(np.exp(1j * phase)))
magnitude_only = np.real(np.fft.ifft2(magnitude))

fig, axes = plt.subplots(2, 2, figsize=(9, 8))
items = [
    (image, "Original image"),
    (np.log1p(np.abs(np.fft.fftshift(spectrum))), "Centered log spectrum"),
    (normalize(phase_only), "Phase-only reconstruction"),
    (normalize(magnitude_only), "Magnitude-only reconstruction"),
]
for axis, (array, title) in zip(axes.ravel(), items):
    axis.imshow(array, cmap="gray")
    axis.set_title(title)
    axis.axis("off")
fig.tight_layout()
fig.savefig(OUTPUT / "spectrum_phase_result.png", dpi=180)

