"""Minimal reproducible examples for Chapter 07.
Run: python chapter07_quick_demo.py
Requires NumPy only. Nothing is downloaded or overwritten.
"""
import numpy as np
from chapter07_wavelet_core import (
    dwt_haar_1d, idwt_haar_1d, synthetic_image, multilevel_haar_2d,
    inverse_multilevel_haar_2d, wavelet_denoise,
)

x = np.array([4, 6, 8, 10], dtype=float)
a, d = dwt_haar_1d(x)
a2, d2 = dwt_haar_1d(a)
assert np.allclose(idwt_haar_1d(a, d), x)
print('Input:', x)
print('Level 1 a:', np.round(a, 4), 'd:', np.round(d, 4))
print('Level 2 a:', np.round(a2, 4), 'd:', np.round(d2, 4))
print('Input energy:', sum(x*x), 'wavelet energy:', sum(a2*a2)+sum(d2*d2)+sum(d*d))

image = synthetic_image(256)
coarse, details = multilevel_haar_2d(image, levels=3)
recovered = inverse_multilevel_haar_2d(coarse, details)
error = np.max(np.abs(recovered - image))
print('Image shape:', image.shape, 'coarsest shape:', coarse.shape)
print('Maximum reconstruction error:', f'{error:.3g}')
assert error < 1e-10

rng = np.random.default_rng(42)
noisy = np.clip(image + rng.normal(0, 20, image.shape), 0, 255)
denoised = wavelet_denoise(noisy, levels=3, threshold=22)
mse_before = float(np.mean((noisy-image)**2))
mse_after = float(np.mean((denoised-image)**2))
print('Noisy MSE:', round(mse_before, 4))
print('Denoised MSE:', round(mse_after, 4))
print('SUCCESS: demonstration executed and exact inverse DWT passed.')
