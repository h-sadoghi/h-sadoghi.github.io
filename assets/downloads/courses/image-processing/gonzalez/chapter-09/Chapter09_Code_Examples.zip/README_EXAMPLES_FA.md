# بستهٔ آزمایش‌های فصل نهم

چهار عمل: erosion، dilation، opening، closing.

- `chapter09_examples.py`: کد مستقل، با داده مصنوعی و آزمون خودکار؛ اجرا: `python chapter09_examples.py --output outputs_ch09`
- `chapter09_examples.ipynb`: Notebook خودبسنده (نیاز به فایل Python کنار خود ندارد).
- `sample_outputs/`: تصاویر تولیدشده با بذر ثابت 42، داده واقعی یا نمونه کتاب نیست.

پیش‌نیاز: `numpy`, `scipy`, `matplotlib` و ترجیحاً `Pillow`.

مستندات علمی: https://scikit-image.org/docs/stable/api/skimage.morphology و مطالعهٔ موردی: https://doi.org/10.3390/drones10020119

هیچ‌گونه فایل CMD، BAT یا تنظیمات سایت در بسته وجود ندارد.
