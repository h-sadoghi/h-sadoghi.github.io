Chapter 10 code examples. Python 3.12+. Dependencies: numpy, matplotlib, Pillow.
Run: py -3.12 chapter10_examples.py
