Original/redrawn educational figures generated for Chapter 10. No textbook page images are included.
