"""Generate original pedagogical diagrams for Texture and SIFT; no figures copied from the textbook."""
from pathlib import Path
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patches
from scipy.ndimage import gaussian_filter
import cv2
D = Path(__file__).resolve().parent/'figures'; D.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.titlesize':12,'figure.dpi':130})
RNG=np.random.default_rng(128)

def save(name):
 plt.tight_layout(pad=1.3); plt.savefig(D/name, dpi=150, bbox_inches='tight'); plt.close('all')

# 06 texture four types
n=160;y,x=np.mgrid[:n,:n]
smooth=gaussian_filter(RNG.normal(size=(n,n)),sigma=15)
coarse=np.where(np.sin(x/11)*np.sin(y/11)>0,1,-1)+.23*RNG.normal(size=(n,n))
periodic=np.sin(x*2*np.pi/16)+np.sin(y*2*np.pi/30)
random=RNG.normal(size=(n,n))
fig,axs=plt.subplots(1,4,figsize=(11,3))
for ax,img,title in zip(axs,[smooth,coarse,periodic,random],['Smooth','Coarse','Periodic','Random']):
 img=(img-img.mean())/(img.std()+1e-12)
 ax.imshow(img,cmap='gray',vmin=-2,vmax=2);ax.set_title(title);ax.axis('off')
save('06_texture_types.png')
# 07 identical histogram, different arrangement
v=np.tile([0,1,0,1],(4,1));h=np.tile(np.array([0,0,1,1])[:,None],(1,4))
fig,axs=plt.subplots(1,3,figsize=(9.6,3.1))
for ax,img,title in zip(axs[:2],[v,h],['Vertical stripes','Horizontal stripes']):
 ax.imshow(img,cmap='gray',vmin=0,vmax=1,interpolation='nearest');ax.set_xticks(range(4));ax.set_yticks(range(4));ax.grid(color='gray',lw=.6);ax.set_title(title)
axs[2].bar([0,1],[8,8],width=.6);axs[2].set(xticks=[0,1],xlabel='Gray level',ylabel='Pixel count',title='Same histogram');save('07_same_hist_different_spatial.png')
# 08 glcm maps
fig,axs=plt.subplots(1,3,figsize=(10,3.6)); matrices=[np.array([[0,2/3],[1/3,0.]]),np.diag([.5,.5]),np.array([[1/3,1/3],[0.,1/3]])]
for ax,P,title in zip(axs,matrices,['Vertical: offset (1,0)','Horizontal: offset (1,0)','Horizontal: offset (0,1)']):
 ax.imshow(P,cmap='Blues',vmin=0,vmax=1);ax.set_xticks([0,1]);ax.set_yticks([0,1]);ax.set_xlabel('neighbor intensity j');ax.set_ylabel('central intensity i');ax.set_title(title)
 for i in range(2):
  for j in range(2):ax.text(j,i,f'{P[i,j]:.2f}',ha='center',va='center',fontsize=13,color='black')
save('08_glcm_example.png')
# 09 direction sensitive GLCM graph using periodic stripes
n=128;img=(np.sin(2*np.pi*np.arange(n)/12)[None,:]>0).astype(float)*np.ones((n,1))
fig,axs=plt.subplots(1,3,figsize=(10.2,3))
axs[0].imshow(img,cmap='gray',vmin=0,vmax=1);axs[0].set_title('Periodic vertical bars')
for ax,(dx,dy),title in zip(axs[1:],[(1,0),(0,1)],['Horizontal pair','Vertical pair']):
 pairs=(img[:n-dy,:n-dx].astype(int)*2+img[dy:,dx:].astype(int)).ravel();P=np.bincount(pairs,minlength=4).reshape((2,2))/len(pairs)
 ax.imshow(P,cmap='Blues',vmin=0,vmax=.55)
 ax.set_xticks([0,1]);ax.set_yticks([0,1]);ax.set_title(title)
 for i in range(2):
  for j in range(2):ax.text(j,i,f'{P[i,j]:.2f}',ha='center',va='center')
axs[0].axis('off');save('09_glcm_orientation.png')
# 10 frequency texture
n=192;y,x=np.mgrid[:n,:n];a=np.sin(2*np.pi*x/20)+.3*np.sin(2*np.pi*y/45);b=np.sin(2*np.pi*y/13)+.18*np.sin(2*np.pi*x/55)
fig,axs=plt.subplots(2,2,figsize=(7.7,7.2))
for i,im in enumerate([a,b]):
 axs[i,0].imshow(im,cmap='gray');axs[i,0].set_title(['Vertical pattern','Horizontal pattern'][i]);axs[i,0].axis('off')
 F=np.fft.fftshift(np.fft.fft2(im));Z=np.log1p(np.abs(F)**2);axs[i,1].imshow(Z,cmap='magma');axs[i,1].set_title('log(1 + |DFT|^2)');axs[i,1].axis('off')
save('10_spectral_texture.png')
#15 sift gaussian pyramid
N=105;Y,X=np.mgrid[:N,:N];f=np.zeros((N,N),dtype=float)
f[((X-41)**2+(Y-38)**2)<18**2]=1;f[((X-73)**2+(Y-72)**2)<12**2]=1
f[25:77,14:22]=.8;f[78:85,10:90]=.7;f=gaussian_filter(f,0.5)
fig,axs=plt.subplots(3,5,figsize=(11,6.5))
for octv in range(3):
 base=cv2.resize(f,None,fx=1/(2**octv),fy=1/(2**octv),interpolation=cv2.INTER_AREA)
 for j in range(5):
  sim=gaussian_filter(base,1.6*2**(j/2));axs[octv,j].imshow(sim,cmap='gray',vmin=0,vmax=1);axs[octv,j].set_title(f'O{octv}, $\\sigma\\propto$ {2**(j/2):.2f}',fontsize=9);axs[octv,j].axis('off')
save('15_sift_scale_space.png')
# 16 3-dimensional extrema neighbourhood
fig=plt.figure(figsize=(8.5,3.7));axs=fig.subplots(1,3)
for k,ax in enumerate(axs):
 mat=np.ones((3,3))*0.23;mat[1,1]=[.28,.96,.37][k]
 ax.imshow(mat,vmin=0,vmax=1,cmap='viridis');ax.set_title(['Scale below','Candidate scale','Scale above'][k]);ax.set_xticks(range(3));ax.set_yticks(range(3));ax.grid(color='white',alpha=.4)
 if k==1:ax.scatter([1],[1],s=330,edgecolor='red',facecolor='none',linewidth=2)
save('16_dog_26_neighbors.png')
#17 sift descriptor: vector field and 4x4x8 concept
fig,axs=plt.subplots(1,2,figsize=(9.4,4.1))
x,y=np.meshgrid(np.arange(16),np.arange(16));ang=np.arctan2(y-7.5,x-7.5)+np.pi/2
weight=np.exp(-((x-7.5)**2+(y-7.5)**2)/70)
axs[0].quiver(x,y,np.cos(ang)*weight,np.sin(ang)*weight,angles='xy',scale_units='xy',scale=.65,width=.005)
axs[0].set_title('Oriented, weighted gradients');axs[0].set_xlim(-1,16);axs[0].set_ylim(16,-1);axs[0].set_aspect('equal')
for off in [3.5,7.5,11.5]:axs[0].axvline(off,c='red',alpha=.5);axs[0].axhline(off,c='red',alpha=.5)
Dvec=[]
for i in range(4):
 for j in range(4):
  v=ang[i*4:(i+1)*4,j*4:(j+1)*4];w=weight[i*4:(i+1)*4,j*4:(j+1)*4]
  h,_=np.histogram((v%(2*np.pi)),bins=np.linspace(0,2*np.pi,9),weights=w);Dvec.extend(h)
axs[1].plot(np.arange(128),Dvec,lw=1.7);axs[1].set(xlabel='Descriptor index',ylabel='Weighted orientation count',title='4 x 4 x 8 = 128 components');save('17_sift_descriptor.png')
# 18 matching of a synthetic image after geometric change
canvas=np.zeros((340,420),np.uint8)+22
rr=np.random.default_rng(447)
for i in range(42):
 x,y=int(rr.integers(20,400)),int(rr.integers(20,320));r=int(rr.integers(4,15));col=int(rr.integers(85,250))
 if i%3==0: cv2.circle(canvas,(x,y),r,col,2)
 elif i%3==1: cv2.rectangle(canvas,(x-r,y-r),(x+r,y+r),col,2)
 else: cv2.line(canvas,(x-r,y),(x+r,y+r),col,2)
cv2.putText(canvas,'FEATURES',(65,205),cv2.FONT_HERSHEY_SIMPLEX,1.05,255,2,cv2.LINE_AA)
mat=cv2.getRotationMatrix2D((210,170),26,.82); warped=cv2.warpAffine(canvas,mat,(420,340),borderValue=22)
sift=cv2.SIFT_create(nfeatures=900)
k1,d1=sift.detectAndCompute(canvas,None);k2,d2=sift.detectAndCompute(warped,None)
matcher=cv2.BFMatcher();raw=matcher.knnMatch(d1,d2,k=2);good=[a for a,b in raw if a.distance<.75*b.distance]
vis=cv2.drawMatches(canvas,k1,warped,k2,good[:28],None,flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
fig,ax=plt.subplots(figsize=(11.2,4.4));ax.imshow(cv2.cvtColor(vis,cv2.COLOR_BGR2RGB));ax.set_title(f'SIFT feature matching after rotation and scaling: {len(good)} ratio-test pairs');ax.axis('off');save('18_sift_matches.png')
print('Generated figures:',len(list(D.glob('*.png'))),'matching_good',len(good))
