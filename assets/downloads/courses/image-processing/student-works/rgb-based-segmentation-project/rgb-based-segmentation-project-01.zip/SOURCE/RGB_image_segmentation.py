import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
import os


# ============================================================
# PARAMETERS
# ============================================================

GAUSSIAN_SIGMA = 2.0

MIN_PEAK_PROMINENCE_RATIO = 0.02
MIN_PEAK_DISTANCE = 10

# Adaptive maximum interval width
MAX_WIDTH_RATIO = 0.6

# Object validation parameters (reserved for later use)
MIN_OBJECT_AREA_RATIO = 0.005
MIN_LARGEST_COMPONENT_RATIO = 0.30

MORPH_KERNEL_SIZE = 5

OUTPUT_DIR = "masked_output"


# ============================================================
# CALCULATE HISTOGRAM
# ============================================================

def calculate_histogram(channel):

    histogram = cv2.calcHist(
        [channel],
        [0],
        None,
        [256],
        [0, 256]
    ).flatten()

    return histogram


# ============================================================
# DETECT PEAKS
# ============================================================

def detect_peaks(histogram):

    smoothed = gaussian_filter1d(
        histogram,
        sigma=GAUSSIAN_SIGMA
    )

    max_value = np.max(smoothed)

    min_prominence = (
        MIN_PEAK_PROMINENCE_RATIO
        * max_value
    )

    peaks, properties = find_peaks(
        smoothed,
        prominence=min_prominence,
        distance=MIN_PEAK_DISTANCE
    )

    return peaks, smoothed, properties


# ============================================================
# FIND ADAPTIVE PEAK INTERVALS
# ============================================================

def find_adaptive_peak_intervals(
    smoothed_histogram,
    peaks,
    max_width_ratio=MAX_WIDTH_RATIO
):

    peaks = np.sort(peaks)

    if len(peaks) == 0:
        return []

    intervals = []

    # --------------------------------------------------------
    # CASE: ONLY ONE PEAK
    # --------------------------------------------------------

    if len(peaks) == 1:

        peak = int(peaks[0])

        left_distance = peak
        right_distance = 255 - peak

        left_width = int(
            left_distance * max_width_ratio
        )

        right_width = int(
            right_distance * max_width_ratio
        )

        lower = max(
            0,
            peak - left_width
        )

        upper = min(
            255,
            peak + right_width
        )

        intervals.append(
            (lower, upper, peak)
        )

        return intervals

    # --------------------------------------------------------
    # CASE: MULTIPLE PEAKS
    # --------------------------------------------------------

    for i, peak in enumerate(peaks):

        peak = int(peak)

        # ====================================================
        # LEFT BOUNDARY
        # ====================================================

        if i == 0:

            distance_to_next = (
                int(peaks[i + 1]) - peak
            )

            max_left_width = int(
                distance_to_next
                * max_width_ratio
            )

        else:

            distance_to_previous = (
                peak - int(peaks[i - 1])
            )

            max_left_width = int(
                distance_to_previous
                * max_width_ratio
            )

        search_start = max(
            0,
            peak - max_left_width
        )

        search_end = peak

        if search_end > search_start:

            region = smoothed_histogram[
                search_start:search_end + 1
            ]

            valley_offset = int(
                np.argmin(region)
            )

            left_boundary = (
                search_start + valley_offset
            )

        else:

            left_boundary = search_start

        # ====================================================
        # RIGHT BOUNDARY
        # ====================================================

        if i == len(peaks) - 1:

            distance_to_previous = (
                peak - int(peaks[i - 1])
            )

            max_right_width = int(
                distance_to_previous
                * max_width_ratio
            )

        else:

            distance_to_next = (
                int(peaks[i + 1]) - peak
            )

            max_right_width = int(
                distance_to_next
                * max_width_ratio
            )

        search_start = peak

        search_end = min(
            255,
            peak + max_right_width
        )

        if search_end > search_start:

            region = smoothed_histogram[
                search_start:search_end + 1
            ]

            valley_offset = int(
                np.argmin(region)
            )

            right_boundary = (
                search_start + valley_offset
            )

        else:

            right_boundary = search_end

        # Ensure the peak is inside the interval
        left_boundary = min(
            left_boundary,
            peak
        )

        right_boundary = max(
            right_boundary,
            peak
        )

        intervals.append(
            (
                int(left_boundary),
                int(right_boundary),
                peak
            )
        )

    return intervals


# ============================================================
# CREATE MASK
# ============================================================
def get_dominant_channel_mask(image_rgb, target_channel_idx):
    dominant_channel = np.argmax(image_rgb, axis=2)
    is_dominant = (dominant_channel == target_channel_idx)
    return (is_dominant.astype(np.uint8)) * 255


def create_mask(channel, lower, upper):

    mask = cv2.inRange(
        channel,
        int(lower),
        int(upper)
    )

    return mask


# ============================================================
# CLEAN MASK
# ============================================================

def clean_mask(mask):

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            MORPH_KERNEL_SIZE,
            MORPH_KERNEL_SIZE
        )
    )

    # Remove small foreground artifacts
    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_OPEN,
        kernel
    )

    # Fill small holes and gaps
    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        kernel
    )

    return mask


# ============================================================
# PROCESS IMAGE: CREATE A SEPARATE MASK FOR EVERY PEAK
# ============================================================

def process_image(
    image_path,
    output_dir=OUTPUT_DIR
):

    # --------------------------------------------------------
    # 1. LOAD IMAGE
    # --------------------------------------------------------

    image_bgr = cv2.imread(image_path)

    if image_bgr is None:
        raise FileNotFoundError(
            f"Could not load image: {image_path}"
        )

    image_rgb = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2RGB
    )

    os.makedirs(
        output_dir,
        exist_ok=True
    )

    # --------------------------------------------------------
    # 2. EXTRACT RGB CHANNELS
    # --------------------------------------------------------

    channels = {
        "red": image_rgb[:, :, 0],
        "green": image_rgb[:, :, 1],
        "blue": image_rgb[:, :, 2]
    }

    results = {}

    # --------------------------------------------------------
    # 3. PROCESS EACH COLOR CHANNEL INDEPENDENTLY
    # --------------------------------------------------------

    channel_indices = {
        "red": 0,
        "green": 1,
        "blue": 2
    }

    for channel_name, channel in channels.items():

        print(
            f"\nProcessing {channel_name.upper()} channel..."
        )

        channel_output_dir = os.path.join(
            output_dir,
            channel_name
        )

        os.makedirs(
            channel_output_dir,
            exist_ok=True
        )

        # Generate dominant channel mask for this channel
        channel_idx = channel_indices[channel_name]
        dominant_mask = get_dominant_channel_mask(image_rgb, channel_idx)

        # Calculate histogram
        histogram = calculate_histogram(
            channel
        )

        # Detect peaks
        peaks, smoothed_histogram, properties = (
            detect_peaks(histogram)
        )

        # Find an intensity interval for each peak
        intervals = find_adaptive_peak_intervals(
            smoothed_histogram,
            peaks
        )

        # Store each peak's results separately
        peak_outputs = []
        channel_combined_mask = np.zeros_like(channel, dtype=np.uint8)

        # ----------------------------------------------------
        # 4. CREATE ONE MASK PER PEAK
        # ----------------------------------------------------

        for peak_index, (
            lower,
            upper,
            peak
        ) in enumerate(intervals, start=1):

            print(
                f"  Peak {peak_index}: "
                f"intensity={peak}, "
                f"interval=[{lower}, {upper}]"
            )

            # 1. Intensity interval mask
            intensity_mask = create_mask(
                channel,
                lower,
                upper
            )

            # 2. Keep only pixels where this channel is dominant
            peak_mask = cv2.bitwise_and(
                intensity_mask,
                dominant_mask
            )

            # 3. Clean this peak's mask independently
            cleaned_mask = clean_mask(
                peak_mask
            )
            channel_combined_mask = cv2.bitwise_or(
                channel_combined_mask,
                cleaned_mask
            )

            # Apply the mask to the original RGB image
            masked_rgb = cv2.bitwise_and(
                image_rgb,
                image_rgb,
                mask=cleaned_mask
            )

            # Unique filenames for this channel and peak
            filename_prefix = (
                f"{channel_name}_"
                f"peak_{peak_index:02d}_"
                f"intensity_{peak}"
            )

            # -----------------------------------------------
            # SAVE BINARY MASK
            # -----------------------------------------------

            mask_path = os.path.join(
                channel_output_dir,
                f"{filename_prefix}_mask.png"
            )

            if not cv2.imwrite(
                mask_path,
                cleaned_mask
            ):
                raise IOError(
                    f"Could not save mask: {mask_path}"
                )

            # -----------------------------------------------
            # SAVE MASKED ORIGINAL IMAGE
            # -----------------------------------------------

            masked_path = os.path.join(
                channel_output_dir,
                f"{filename_prefix}_masked.png"
            )

            masked_bgr = cv2.cvtColor(
                masked_rgb,
                cv2.COLOR_RGB2BGR
            )

            if not cv2.imwrite(
                masked_path,
                masked_bgr
            ):
                raise IOError(
                    f"Could not save image: {masked_path}"
                )

            # -----------------------------------------------
            # STORE RESULTS IN MEMORY
            # -----------------------------------------------

            peak_outputs.append({
                "peak_index": peak_index,
                "peak": int(peak),
                "interval": (
                    int(lower),
                    int(upper)
                ),
                "mask": cleaned_mask,
                "masked_image": masked_rgb,
                "mask_path": mask_path,
                "masked_image_path": masked_path
            })

            print(f"    Mask saved: {mask_path}")
            print(f"    Image saved: {masked_path}")

        # ----------------------------------------------------
        # 5. STORE CHANNEL RESULTS
        # ----------------------------------------------------

        results[channel_name] = {
            "histogram": histogram,
            "smoothed_histogram": smoothed_histogram,
            "peaks": peaks,
            "intervals": intervals,
            "peak_outputs": peak_outputs
        }

        print(
            f"{channel_name.upper()}: "
            f"{len(peaks)} peaks detected; "
            f"{len(peak_outputs)} individual "
            f"mask/image pairs saved."
        )

        if len(peaks) == 0:
            print(
                "  No peaks met the detection criteria."
            )

        # ----------------------------------------------------
        # 5. SAVE PER-CHANNEL COMBINED RESULTS
        # ----------------------------------------------------
        if len(intervals) > 0:
            channel_masked_rgb = cv2.bitwise_and(
                image_rgb,
                image_rgb,
                mask=channel_combined_mask
            )
    
            combined_mask_path = os.path.join(
                channel_output_dir,
                f"{channel_name}_all_peaks_combined_mask.png"
            )
            combined_masked_path = os.path.join(
                channel_output_dir,
                f"{channel_name}_all_peaks_combined_masked.png"
            )
    
            cv2.imwrite(combined_mask_path, channel_combined_mask)
            cv2.imwrite(combined_masked_path, cv2.cvtColor(channel_masked_rgb, cv2.COLOR_RGB2BGR))
    
            print(f"  [SAVED] {channel_name.upper()} combined image: {combined_masked_path}")
    
        results[channel_name] = {
            "peaks": peaks,
            "intervals": intervals,
            "peak_outputs": peak_outputs,
            "combined_mask": channel_combined_mask
        }

    print(
        f"\nAll results have been saved in: "
        f"{os.path.abspath(output_dir)}"
    )

    return results
    
# ============================================================
# RUN THE PROGRAM
# ============================================================

if __name__ == "__main__":

    default_path = (
        "/Users/apple/Desktop/"
        "digital-image-processing/"
        "Stanford-University.jpg"
    )

    image_path = input(
        f"Enter image path [default: {default_path}]: "
    ).strip().strip('"').strip("'")

    if not image_path:
        image_path = default_path

    results = process_image(
        image_path,
        output_dir=OUTPUT_DIR
    )