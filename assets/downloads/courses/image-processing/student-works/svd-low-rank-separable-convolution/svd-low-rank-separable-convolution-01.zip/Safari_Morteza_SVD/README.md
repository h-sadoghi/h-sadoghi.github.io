# SVD, Low-Rank Approximation, and Separable Convolution — Persian notes

این پوشه شامل جزوهٔ ریاضی فارسی (XeLaTeX + PDF)، شش شکل برداری تولیدشده، کد بازتولید شکل‌ها و نتایج عددی است.

## محتوا

- `SVD_Separable_Convolution_FA.pdf` — نسخهٔ مطالعه، ۱۷ صفحه
- `SVD_Separable_Convolution_FA.tex` — متن قابل ویرایش، با بلوک فونت درخواست‌شده پیش از عنوان
- `figures/` — شش شکل برداری PDF (اصیل؛ به منبع بیرونی تعلق ندارند)
- `make_figures.py` — تولید تمام شکل‌ها و بازتولید نتایج عددی
- `numerical_results.txt` — مقدارهای دقیق آزمایش، شامل اختلاف بازسازی کامل SVD

## بازتولید

ابتدا از پوشهٔ اصلی پروژه اجرا کنید:

```bash
python -m pip install numpy scipy matplotlib
python make_figures.py
xelatex -interaction=nonstopmode -halt-on-error SVD_Separable_Convolution_FA.tex
xelatex -interaction=nonstopmode -halt-on-error SVD_Separable_Convolution_FA.tex
```

ابتدا فونت **B Nazanin** با `\IfFontExistsTF` بررسی می‌شود؛ اگر روی سیستم نصب نباشد، **DejaVu Sans** انتخاب خواهد شد. خود متن یا PDF نیازی به دریافت تصویر از اینترنت ندارد. تمام پیوندهای مراجع دانشگاهی در بخش منابع جزوه آمده است.

## محدودهٔ اثبات‌ها

اثبات کامل: شرط رنک یک، حداقل تعداد جمله‌های تجزیهٔ دقیق، محاسبهٔ خطای طیفِ حذف‌شده، اثبات «بهینگی جهانی» Eckart–Young–Mirsky در نرم فروبنیوس با تصویرگر متعامد، اثبات نسخهٔ نرم طیفی با اشتراک زیرفضاها و کران خطای کانولوشن.

**توجه علمی:** قضیهٔ Eckart–Young–Mirsky دربارهٔ نزدیک‌ترین *ماتریس پنجره* است؛ لزوماً خطای خروجی فیلتر روی هر تصویر دلخواه را بهینه نمی‌کند.
