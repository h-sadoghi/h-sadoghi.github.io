"""Reproduce all original figures in the Persian SVD/separable-convolution note.
Dependencies: numpy, scipy, matplotlib. No network, photographs, or external assets.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import convolve, convolve1d

D=Path(__file__).resolve().parent/'figures';D.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.unicode_minus':False})

def save(fig,name):
    fig.savefig(D/name,bbox_inches='tight',pad_inches=.13)
    plt.close(fig)

# Diagram: exact rank-one decomposition
fig,axs=plt.subplots(1,3,figsize=(9,2.45),gridspec_kw={'width_ratios':[1.25,.48,1.25]})
H=np.array([[1,2,1],[2,4,2],[1,2,1]])/16
for ax,A,title in zip(axs,[H,np.array([[1],[2],[1]])/4,np.array([[1,2,1]])/4],['H: 3 x 3','a: 3 x 1','b^T: 1 x 3']):
 ax.imshow(A,cmap='Blues',vmin=0,vmax=.25,aspect='equal');ax.set_title(title)
 ax.set_xticks([]);ax.set_yticks([])
 for (i,j),v in np.ndenumerate(A):ax.text(j,i,f'{v:.3f}',ha='center',va='center',fontsize=9,color='black')
 for spine in ax.spines.values():spine.set_visible(False)
fig.text(.375,.49,'=',ha='center',fontsize=24)
fig.text(.614,.49,'x',ha='center',fontsize=24)
fig.suptitle('Rank-one kernel = outer product of two 1-D filters',fontsize=12)
save(fig,'fig1_rank_one.pdf')

# spectrum of simple exactly soluble matrix
S=np.array([3.,1.,.2]); energy=np.cumsum(S**2)/np.sum(S**2)*100
fig,ax=plt.subplots(1,2,figsize=(9.6,3.1))
ax[0].bar([1,2,3],S);ax[0].set(xticks=[1,2,3],xlabel='Index i',ylabel='Singular value',title='Singular spectrum')
ax[1].plot([1,2,3],energy,'o-',lw=2);ax[1].set(xticks=[1,2,3],ylim=[80,101],xlabel='Retained rank k',ylabel='Energy retained (%)',title='Cumulative singular-value energy')
for k,e in enumerate(energy,1):ax[1].annotate(f'{e:.2f}%',(k,e),xytext=(0,9),textcoords='offset points',ha='center')
fig.tight_layout();save(fig,'fig2_spectrum.pdf')

# rotated anisotropic Gaussian - *nonseparable* sampled filter
n=19;q=np.arange(-(n//2),n//2+1);xx,yy=np.meshgrid(q,q)
H=np.exp(-(0.52*xx**2+0.95*yy**2+0.45*xx*yy)/18.0); H/=H.sum()
U,s,Vt=np.linalg.svd(H,full_matrices=False)
Ks=[1,2,4,8]
fig,axs=plt.subplots(1,5,figsize=(11.0,2.75))
for ax,k in zip(axs,[0]+Ks):
 A=H if k==0 else (U[:,:k]*s[:k])@Vt[:k,:]
 ax.imshow(A,cmap='viridis',interpolation='nearest',vmin=H.min(),vmax=H.max())
 ax.set_title('Original H' if k==0 else f'Rank {k}\nerr={np.linalg.norm(H-A):.2e}',fontsize=9)
 ax.set_xticks([]);ax.set_yticks([])
fig.tight_layout();save(fig,'fig3_kernel_approximations.pdf')

# synthetic image / output comparison
h,w=184,256
Y,X=np.mgrid[0:h,0:w]
I=.15+.27*(X>=90)+.25*((X-177)**2+(Y-81)**2<38**2)+.18*np.sin(.12*X+.04*Y)**2
I+=.11*((X//8+Y//8)%2)*(X>150)*(Y>113)
I=np.clip(I,0,1)
ref=convolve(I,H,mode='constant',cval=0.0)
res=[]
for k in [1,2,4]:
 Z=np.zeros_like(I)
 for i in range(k):
  v=np.sqrt(s[i])*Vt[i,:]
  u=np.sqrt(s[i])*U[:,i]
  tmp=convolve1d(I,v,axis=1,mode='constant',cval=0.0)
  Z+=convolve1d(tmp,u,axis=0,mode='constant',cval=0.0)
 err=np.linalg.norm(Z-ref)/np.linalg.norm(ref)
 res.append((k,Z,err))
fig,axs=plt.subplots(2,3,figsize=(11.0,5.4))
for ax,dat,title in [(axs[0,0],I,'Input image (synthetic)'),(axs[0,1],ref,'Full 2-D convolution')]+[(axs[0,2],res[0][1],f'Rank-1 output, rel.err={res[0][2]:.2%}')]:
 ax.imshow(dat,cmap='gray',vmin=0,vmax=1);ax.set_title(title,fontsize=9);ax.axis('off')
for ax,(k,out,err) in zip(axs[1],res):
 ax.imshow(np.abs(ref-out),cmap='magma');ax.set_title(f'|Full - rank {k}|, rel.err={err:.2%}',fontsize=9);ax.axis('off')
fig.tight_layout();save(fig,'fig4_filtered_examples.pdf')

# complexity and approximation tradeoff
fig,ax=plt.subplots(1,2,figsize=(10.4,3.1))
ns=np.arange(3,51,2)
ax[0].plot(ns,ns**2,'-',label='Direct: n^2')
for k in [1,2,4]:ax[0].plot(ns,2*k*ns,label=f'SVD rank {k}: 2kn')
ax[0].legend(fontsize=8);ax[0].set(xlabel='Kernel side n',ylabel='Multiply counts per pixel',title='Arithmetic cost (idealized)')
ranks=np.arange(0,n+1);tail=np.array([np.linalg.norm(s[k:])/np.linalg.norm(s) for k in ranks]);
ax[1].semilogy(ranks,tail+1e-16,'o-',markersize=3);ax[1].set(xlim=(0,10),xlabel='Rank retained k',ylabel='Relative kernel Frobenius error',title='Accuracy vs retained rank')
fig.tight_layout();save(fig,'fig5_tradeoff.pdf')

# Exact 2-term decomposition of Laplacian kernel
L=np.array([[0,1,0],[1,-4,1],[0,1,0]])
A=np.outer([1,0,1],[0,1,0]);B=np.outer([0,1,0],[1,-4,1]);assert np.array_equal(A+B,L)
fig,axs=plt.subplots(1,3,figsize=(9.3,2.7))
for ax,M,name in zip(axs,[L,A,B],['Laplacian (rank 2)','Rank-one term A','Rank-one term B']):
 ax.imshow(M,cmap='coolwarm',vmin=-4,vmax=4);ax.set_title(name)
 for (i,j),v in np.ndenumerate(M):ax.text(j,i,str(v),ha='center',va='center',fontsize=12)
 ax.set_xticks([]);ax.set_yticks([])
fig.tight_layout();save(fig,'fig6_laplacian_rank2.pdf')

# numeric metadata for reproducibility
out=[]
out.append('Exact 3x3 example singular values: '+str(np.linalg.svd(np.array([[2.,1.,0.],[1.,2.,0.],[0.,0.,.2]]),compute_uv=False)))
out.append('Synthetic 19x19 filter singular values: '+', '.join(f'{z:.9e}' for z in s[:8]))
out.append('rank k | kernel relative Frobenius error | output relative L2 error')
for k,Z,err in res:
 out.append(f'{k} | {np.linalg.norm(H-(U[:,:k]*s[:k])@Vt[:k,:])/np.linalg.norm(H):.9e} | {err:.9e}')
Zfull=np.zeros_like(I)
for j in range(n):
    z=convolve1d(I,np.sqrt(s[j])*Vt[j,:],axis=1,mode="constant",cval=0.0)
    Zfull+=convolve1d(z,np.sqrt(s[j])*U[:,j],axis=0,mode="constant",cval=0.0)
out.append('Full 2d vs exact full-SVD sequential max diff: '+str(np.max(np.abs(ref-Zfull))))
(D.parent/'numerical_results.txt').write_text('\n'.join(out)+'\n',encoding='utf-8')
print('\n'.join(out))
