import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# 1. Setup output directory (images folder in project root)
IMAGE_DIR = Path("images")
IMAGE_DIR.mkdir(parents=True, exist_ok=True)
np.random.seed(42)

# ==========================================
# PART 1: Generate Synthetic 2-Cluster Dataset + Boundary Sample
# ==========================================
cluster1 = np.random.normal(loc=[2.0, 3.0], scale=0.55, size=(35, 2))
cluster2 = np.random.normal(loc=[6.0, 3.0], scale=0.55, size=(35, 2))
special_points = np.array([
    [2.0, 3.0],  # Sample A: Core of Cluster 1
    [4.0, 3.0],  # Sample B: Boundary Point Between Clusters
    [6.0, 3.0]   # Sample C: Core of Cluster 2
])
X = np.vstack([cluster1, cluster2, special_points])

# ==========================================
# PART 2: Bezdek's Fuzzy Objective Optimization
# ==========================================
def optimize_bezdek_fcm(X, c=2, m=2.0, max_iter=100, tol=1e-6):
    n = X.shape[0]
    # Dirichlet initialization guarantees sum_{j=1}^c u_ij = 1
    U = np.random.dirichlet(np.ones(c), size=n)
    for _ in range(max_iter):
        um = U ** m
        centers = (um.T @ X) / np.sum(um, axis=0)[:, None]
        dists = np.linalg.norm(X[:, None, :] - centers[None, :, :], axis=2)
        dists = np.fmax(dists, 1e-10)
        power = 2.0 / (m - 1.0)
        U_new = 1.0 / np.sum((dists[:, :, None] / dists[:, None, :]) ** power, axis=2)
        if np.linalg.norm(U_new - U) < tol:
            break
        U = U_new

    if centers[0, 0] > centers[1, 0]:
        centers = centers[::-1]
        U = U[:, ::-1]
        
    return centers, U

centers, U = optimize_bezdek_fcm(X, c=2, m=2.0)

# Print Bezdek's unknown variables count & sample rows of U_(n x c)
n_samples, d_features = X.shape
c_clusters = 2
print(f"Total Samples (n): {n_samples}, Clusters (c): {c_clusters}, Dimension (d): {d_features}")
print(f"Unknowns in Matrix U (n x c): {n_samples * c_clusters}")
print(f"Unknowns in Prototypes mu:    {c_clusters * d_features}\n")

print("=== SAMPLE ROWS OF BEZDEK PARTITION MATRIX U_(n x c) ===")
sample_names = ["Sample A (Core C1 [2,3])", "Sample B (Boundary [4,3])", "Sample C (Core C2 [6,3])"]
for idx, name in zip([-3, -2, -1], sample_names):
    u1, u2 = U[idx]
    print(f"{name:26s} -> u_i1 = {u1:.4f}, u_i2 = {u2:.4f}, Sum = {u1+u2:.2f} | Weight u_i1^m = {u1**2:.4f}")

# ==========================================
# FIGURE 1: Hard Partitioning vs. Bezdek Fuzzy Membership & Matrix U
# ==========================================
fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))

# Panel 1: Visual Heatmap of Representative Rows in U_(n x c)
u_subset = U[[-3, -2, -1], :]
im = axes[0].imshow(u_subset, cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
axes[0].set_xticks([0, 1])
axes[0].set_xticklabels(["Cluster 1 (u_i1)", "Cluster 2 (u_i2)"], fontweight="bold")
axes[0].set_yticks([0, 1, 2])
axes[0].set_yticklabels(["Core C1 [2,3]", "Boundary [4,3]", "Core C2 [6,3]"], fontweight="bold")
for r in range(3):
    for col in range(2):
        val = u_subset[r, col]
        axes[0].text(col, r, f"{val:.2f}", ha="center", va="center",
                     color="white" if val > 0.5 else "black", fontsize=11, fontweight="bold")
axes[0].set_title("1. Entries of Matrix U_(n x c) [Row Sum = 1]")

# Panel 2: Hard Partitioning (Binary 0 or 1)
hard_labels = np.argmax(U, axis=1)
axes[1].scatter(X[:, 0], X[:, 1], c=hard_labels, cmap="coolwarm", s=50, edgecolors="k")
axes[1].scatter(centers[:, 0], centers[:, 1], c="yellow", marker="D", s=130, edgecolors="black")
axes[1].annotate("Forced Binary (0 or 1)!", xy=(4.0, 3.0), xytext=(2.6, 4.3),
                 arrowprops=dict(arrowstyle="->", lw=1.5, color="black"), fontweight="bold")
axes[1].set_title("2. Hard Partitioning (Binary 0/1)")
axes[1].grid(True, alpha=0.3)

# Panel 3: Bezdek's Fuzzy Membership (Continuous u_ij)
sc = axes[2].scatter(X[:, 0], X[:, 1], c=U[:, 0], cmap="coolwarm", s=55, edgecolors="k", vmin=0, vmax=1)
axes[2].scatter(centers[:, 0], centers[:, 1], c="yellow", marker="D", s=130, edgecolors="black")
axes[2].annotate(f"u_i1 = {U[-2,0]:.2f}, u_i2 = {U[-2,1]:.2f}\n(u_i1 + u_i2 = 1.00)",
                 xy=(4.0, 3.0), xytext=(2.5, 4.15),
                 arrowprops=dict(arrowstyle="->", lw=1.5, color="darkblue"), fontweight="bold", fontsize=9)
axes[2].set_title("3. Bezdek Fuzzy Membership (u_ij)")
axes[2].grid(True, alpha=0.3)
plt.colorbar(sc, ax=axes[2], label="Membership Degree u_i1")

plt.tight_layout()
plt.savefig(IMAGE_DIR / "comparison_three_methods.png", dpi=180)
plt.close()

# ==========================================
# FIGURE 2: Cluster Perception Filter & Non-Linear Damping Filter (2 Panels)
# ==========================================
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.4))

# Panel 1: How Cluster 1 "Sees" the Data (Weighted by u_i1^m)
weights_c1 = U[:, 0] ** 2.0
axes[0].scatter(X[:, 0], X[:, 1], c="royalblue", alpha=np.clip(weights_c1, 0.06, 1.0),
                s=30 + 90 * weights_c1, edgecolors="black", linewidth=0.6)
axes[0].scatter(*centers[0], c="gold", marker="*", s=260, edgecolors="black", label="Center mu_1")
axes[0].annotate("u_i1^m ~ 1.0\n(Fully Seen)", xy=(2.0, 3.0), xytext=(0.8, 4.3),
                 arrowprops=dict(arrowstyle="->", lw=1.3), fontsize=9, fontweight="bold")
axes[0].annotate("u_i1^m ~ 0.0\n(Ignored!)", xy=(6.0, 3.0), xytext=(4.8, 4.3),
                 arrowprops=dict(arrowstyle="->", lw=1.3, color="gray"), fontsize=9, color="dimgray")
axes[0].set_title("1. Data Seen by Cluster 1 (Weight u_i1^m)")
axes[0].legend(loc="lower left")
axes[0].grid(True, alpha=0.3)

# Panel 2: Non-Linear Damping Filter w = u^m
u_vals = np.linspace(0, 1, 200)
for m_val, col, ls in [(1.0, "gray", "--"), (2.0, "navy", "-"), (4.0, "seagreen", ":")]:
    axes[1].plot(u_vals, u_vals ** m_val, color=col, linestyle=ls, lw=2.2, label=f"m = {m_val}")
axes[1].scatter([0.2, 0.9], [0.04, 0.81], color="crimson", zorder=5)
axes[1].annotate("0.2^2 = 0.04\n(Suppressed)", xy=(0.2, 0.04), xytext=(0.28, 0.18),
                 arrowprops=dict(arrowstyle="->", color="crimson"), fontsize=8.5)
axes[1].set_title("2. Non-Linear Damping Filter (w = u^m)")
axes[1].set_xlabel("Raw Membership (u_ij)")
axes[1].set_ylabel("Effective Weight in Loss (u_ij^m)")
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(IMAGE_DIR / "cluster_perception_and_m.png", dpi=180)
plt.close()

# ==========================================
# FIGURE 3: Spatial Transition vs. Knob (m) for m in [1.1, ..., 20] & m=150 (Approx. inf)
# ==========================================
fig, axes = plt.subplots(1, 2, figsize=(15.0, 5.2))
x_line = np.linspace(0, 8, 500)
c1, c2 = 2.0, 6.0
d1 = np.abs(x_line - c1) + 1e-9
d2 = np.abs(x_line - c2) + 1e-9

# Panel 1: Low-to-Moderate Fuzziness Regime (m = 1.1, 2, 3, ..., 10)
m_regime1 = [1.1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
colors1 = plt.cm.tab10(np.linspace(0, 1, len(m_regime1)))

for idx, m_val in enumerate(m_regime1):
    u1 = 1.0 / (1.0 + (d1 / d2) ** (2.0 / (m_val - 1.0)))
    ls = "--" if m_val == 1.1 else ("-" if m_val in [2, 3] else "-.")
    lw = 2.4 if m_val in [1.1, 2, 3] else 1.5
    axes[0].plot(x_line, u1, linestyle=ls, color=colors1[idx], lw=lw, label=f"m = {m_val}")

axes[0].axvline(c1, color="gray", alpha=0.45, linestyle=":")
axes[0].axvline(c2, color="gray", alpha=0.45, linestyle=":")
axes[0].axhline(0.5, color="black", alpha=0.35, linestyle="--", lw=1.0)
axes[0].scatter([4.0], [0.5], color="black", s=45, zorder=6)
axes[0].annotate("Pivot (4.0, 0.5)", xy=(4.0, 0.5), xytext=(4.35, 0.58),
                 arrowprops=dict(arrowstyle="->", lw=1.1, color="black"), fontsize=8.5, fontweight="bold")
axes[0].set_title("1. Structural Transition Regime (m = 1.1 to 10)")
axes[0].set_xlabel("Sample Position (x)")
axes[0].set_ylabel("Membership Degree u_i1(x)")
axes[0].set_ylim(-0.03, 1.05)
axes[0].legend(ncol=2, fontsize=8.5, loc="upper right", framealpha=0.92)
axes[0].grid(True, alpha=0.3)

# Panel 2: High Fuzziness Regime (m = 11, ..., 20) + Numerical Approximation of m -> inf (m = 150)
m_regime2 = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
colors2 = plt.cm.viridis(np.linspace(0.05, 0.90, len(m_regime2)))

for idx, m_val in enumerate(m_regime2):
    u1 = 1.0 / (1.0 + (d1 / d2) ** (2.0 / (m_val - 1.0)))
    ls = "-" if m_val in [11, 15, 20] else "--"
    lw = 2.1 if m_val in [11, 20] else 1.35
    axes[1].plot(x_line, u1, linestyle=ls, color=colors2[idx], lw=lw, label=f"m = {m_val}")

# Approximate curve for m -> infinity using m = 150 (clearly visible without overlapping horizontal line)
m_approx_inf = 150.0
u1_approx_inf = 1.0 / (1.0 + (d1 / d2) ** (2.0 / (m_approx_inf - 1.0)))
axes[1].plot(x_line, u1_approx_inf, linestyle="-.", color="crimson", lw=2.5, zorder=6,
             label="m = 150 (Approx. m -> inf)")

axes[1].axvline(c1, color="gray", alpha=0.45, linestyle=":")
axes[1].axvline(c2, color="gray", alpha=0.45, linestyle=":")
axes[1].scatter([4.0], [0.5], color="crimson", s=50, zorder=7)
axes[1].annotate("Approx. m -> inf (m=150)\n Approaches u_i1 = 1/c = 0.5",
                 xy=(1.1, float(1.0 / (1.0 + (np.abs(1.1 - c1) / np.abs(1.1 - c2)) ** (2.0 / (m_approx_inf - 1.0))))),
                 xytext=(0.25, 0.18),
                 arrowprops=dict(arrowstyle="->", lw=1.4, color="crimson"),
                 fontsize=8.5, color="crimson", fontweight="bold")

axes[1].set_title("2. Saturation Regime (m = 11 to 20) & Approx. Limit (m = 150)")
axes[1].set_xlabel("Sample Position (x)")
axes[1].set_ylabel("Membership Degree u_i1(x)")
axes[1].set_ylim(-0.03, 1.05)
axes[1].legend(ncol=2, fontsize=8.0, loc="upper right", framealpha=0.94)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(IMAGE_DIR / "spatial_transition_m_1_to_20.png", dpi=180)
plt.close()